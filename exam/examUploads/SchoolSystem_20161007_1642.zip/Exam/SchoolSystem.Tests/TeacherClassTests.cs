﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using NUnit.Framework;

namespace SchoolSystem.Tests
{
    public class TeacherClassTests
    {
        public void TestMethod1()
        {
        }
    }
}
