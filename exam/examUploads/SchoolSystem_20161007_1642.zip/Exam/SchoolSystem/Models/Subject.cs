﻿namespace SchoolSystem.Models
{
    public enum Subject
    {
        Bulgarian,
        English,
        Math,
        Programming
    }
}
